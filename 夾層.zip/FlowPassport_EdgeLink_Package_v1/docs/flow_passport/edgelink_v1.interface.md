# EdgeLink v1 — 通道抽象（不綁 QUIC/WS/HTTP）

## 介面（概念）
- open(peer)
- send(frame)
- onFrame(handler)
- onStateChange(handler)
- close()

## 原則
- EdgeLink 只負責通道材料，不裁決身份與通行
- Trace/Heartbeat/Merkle/Signature 必須由上層夾層提供
- Adapter 可替換：WS / QuicLike / HTTP / 其他

## Frame（最小）
trace_id + trace(event_id,rid,tick,persona_id,merkle_root,ts_ms) + payload(bytes)
