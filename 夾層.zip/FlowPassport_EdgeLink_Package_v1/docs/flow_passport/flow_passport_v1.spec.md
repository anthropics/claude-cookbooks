# Flow Passport v1 — 通行原則與邊界（系統定稿）

## 1. 定義
通行不是授權；通行＝平行世界在時間窗內「重疊＋合偶」成立的事件（本地可證、無遠端裁決）。

## 2. 邊界
平台只應封裝其資源邊界：server ingress/egress、算力、頻寬、儲存；不得擴張為存在/身份裁決。

## 3. 協商
其餘通行與關係：人↔人點對點、端↔端端對端、AI↔AI與多代理世界內生協商；成本與責任按因果對齊，避免制度性失衡。

## 4. 不變量（Overlap Invariants）
- origin_signature：根來源（本地信任錨）
- persona_id：存在識別
- trace_id：事件線索（rid:event_id 或等價映射）
- merkle_root：狀態完整性錨
- heartbeat_tick：節奏時間序
- issued_at/expires_at：時效窗
- signature：本地可驗證簽章（無遠端查詢）

## 5. 驗證流程（摘要）
1) 本地驗證欄位完整性
2) 時效窗（expires）與 tick 單調/漂移檢查
3) merkle_root 與 signature 驗證（本地）
4) 合偶判定：雙向映射可成立（A→B 與 B→A 在同一時間窗）

## 6. 非目標
- 帳號/tenant/方案/計費語義
- 第三方裁決依賴
