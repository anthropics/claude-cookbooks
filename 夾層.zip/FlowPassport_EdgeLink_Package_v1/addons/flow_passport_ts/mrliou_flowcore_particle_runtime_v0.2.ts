// mrliou_flowcore_particle_runtime_v0.2.ts
// NOTE: This package includes the runtime slot for EdgeLink + Trace.
// If you already have the canonical single-file runtime, replace this file with your signed version.
export const PLACEHOLDER = true;
