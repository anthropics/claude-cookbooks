"""
Coupling (合偶) check: bidirectional mapping must hold in the overlap window.

This is intentionally minimal: provide hooks to map A<->B tokens
(e.g., trace_id mapping or session mapping).
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Tuple, Any

@dataclass
class CouplingResult:
    ok: bool
    reason: str

def couple(
    a: Any,
    b: Any,
    map_a_to_b: Callable[[Any], str],
    map_b_to_a: Callable[[Any], str],
) -> CouplingResult:
    try:
        ab = map_a_to_b(a)
        ba = map_b_to_a(b)
        # minimal symmetric condition: mapped ids must match the other side's id representation
        if ab != getattr(b, "trace_id", None) and ab != getattr(b, "id", None):
            return CouplingResult(False, "A->B mapping mismatch")
        if ba != getattr(a, "trace_id", None) and ba != getattr(a, "id", None):
            return CouplingResult(False, "B->A mapping mismatch")
        return CouplingResult(True, "ok")
    except Exception as e:
        return CouplingResult(False, f"coupling exception: {e}")
