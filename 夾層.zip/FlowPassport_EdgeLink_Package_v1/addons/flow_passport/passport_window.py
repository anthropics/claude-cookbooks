"""
Overlap window checks: monotonic tick + drift gate.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple

@dataclass
class TickWindow:
    last_tick: int = -1
    max_backward: int = 0
    max_forward_jump: int = 10_000

    def check(self, tick: int) -> Tuple[bool, str]:
        if tick < 0:
            return False, "tick<0"
        if self.last_tick >= 0:
            if tick + self.max_backward < self.last_tick:
                return False, "tick went backward beyond tolerance"
            if tick - self.last_tick > self.max_forward_jump:
                return False, "tick jumped forward beyond tolerance"
        self.last_tick = max(self.last_tick, tick)
        return True, "ok"
