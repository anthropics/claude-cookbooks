"""
Flow Passport v1 (Python) — minimal local verifier.
No external authority. No tenant/account semantics.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Dict, Any, Tuple
import base64
import time
import hmac
import hashlib

@dataclass(frozen=True)
class FlowPassport:
    origin_signature: str
    persona_id: str
    trace_id: str
    merkle_root: str
    heartbeat_tick: int
    issued_at: int
    expires_at: int
    signature_b64: str

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "FlowPassport":
        return FlowPassport(
            origin_signature=str(d.get("origin_signature","")),
            persona_id=str(d.get("persona_id","")),
            trace_id=str(d.get("trace_id","")),
            merkle_root=str(d.get("merkle_root","")),
            heartbeat_tick=int(d.get("heartbeat_tick", -1)),
            issued_at=int(d.get("issued_at", 0)),
            expires_at=int(d.get("expires_at", 0)),
            signature_b64=str(d.get("signature","")),
        )

def _canonical_payload(p: FlowPassport) -> bytes:
    # Deterministic canonicalization
    s = f"{p.origin_signature}|{p.persona_id}|{p.trace_id}|{p.merkle_root}|{p.heartbeat_tick}|{p.issued_at}|{p.expires_at}"
    return s.encode("utf-8")

def sign_passport(passport: FlowPassport, secret: bytes) -> str:
    mac = hmac.new(secret, _canonical_payload(passport), hashlib.sha256).digest()
    return base64.b64encode(mac).decode("ascii")

def verify_signature(passport: FlowPassport, secret: bytes) -> Tuple[bool, str]:
    try:
        sig = base64.b64decode(passport.signature_b64.encode("ascii"))
    except Exception:
        return False, "invalid signature encoding"
    mac = hmac.new(secret, _canonical_payload(passport), hashlib.sha256).digest()
    if not hmac.compare_digest(sig, mac):
        return False, "signature mismatch"
    return True, "ok"

def verify_fields(passport: FlowPassport) -> Tuple[bool, str]:
    if not passport.origin_signature:
        return False, "missing origin_signature"
    if not passport.persona_id:
        return False, "missing persona_id"
    if not passport.trace_id:
        return False, "missing trace_id"
    if not passport.merkle_root:
        return False, "missing merkle_root"
    if passport.heartbeat_tick < 0:
        return False, "invalid heartbeat_tick"
    if passport.issued_at <= 0 or passport.expires_at <= 0:
        return False, "invalid time window"
    if passport.expires_at <= passport.issued_at:
        return False, "expires_at <= issued_at"
    return True, "ok"

def verify_time_window(passport: FlowPassport, now_ms: Optional[int] = None, allow_clock_skew_ms: int = 30_000) -> Tuple[bool, str]:
    now = int(now_ms if now_ms is not None else time.time() * 1000)
    if now + allow_clock_skew_ms < passport.issued_at:
        return False, "issued_at in future (beyond skew)"
    if now - allow_clock_skew_ms > passport.expires_at:
        return False, "expired"
    return True, "ok"
